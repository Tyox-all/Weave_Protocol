/**
 * Dōmere - The Judge Protocol
 * Storage Module
 */

export { MemoryStorage, createStorage } from './memory.js';
