/**
 * Hord - The Vault Protocol
 * Attestation Module
 */

export * from './service.js';
